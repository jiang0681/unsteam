#include <windows.h>
#define RtlGenRandom SystemFunction036
#define DLLEXPORT 	__declspec(dllexport)
DLLEXPORT BOOLEAN WINAPI RtlGenRandom(PVOID in, ULONG len) {}