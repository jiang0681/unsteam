This is a git bundle of the full repo, to use: git clone source_code.bundle --branch master
